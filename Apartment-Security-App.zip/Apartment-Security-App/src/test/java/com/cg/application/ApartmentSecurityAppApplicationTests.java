package com.cg.application;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApartmentSecurityAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
